import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    var widthT = screensize.width;
    var heightT = screensize.height;
    return new Scaffold(
      appBar: AppBar(
        title: Text("Resume Builder"),
        backgroundColor: Colors.blueAccent,
        elevation: 0,
      ),
      body: Container(
          height: heightT,
          width: widthT,
          color: Colors.white70,
          child: 1 == 0
              ? Container(
                  child: Center(
                    child: OutlinedButton(
                      child: Icon(
                        Icons.add,
                        size: 30,
                      ),
                      style: OutlinedButton.styleFrom(
                          primary: Colors.blueAccent,
                          onSurface: Colors.blueAccent,
                          side: BorderSide(color: Colors.blueAccent, width: 1)),
                      onPressed: () {},
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: 5,
                  itemBuilder: (BuildContext context, int index) {
                    return ListTile(
                        leading: Icon(Icons.list),
                        trailing: ElevatedButton(
                            style:
                                ElevatedButton.styleFrom(primary: Colors.white),
                            onPressed: () {},
                            child: Text(
                              "open",
                              style: TextStyle(color: Colors.blueAccent),
                            )),
                        title: Text("List item $index"));
                  })),
    );
  }
}
