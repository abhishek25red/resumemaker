import 'package:flutter/material.dart';

class Detailsfill extends StatefulWidget {
  const Detailsfill({ Key? key }) : super(key: key);

  @override
  State<Detailsfill> createState() => _DetailsfillState();
}

class _DetailsfillState extends State<Detailsfill> {
  @override
  Widget build(BuildContext context) {
    var screensize = MediaQuery.of(context).size;
    var widthT = screensize.width;
    var heightT = screensize.height;
    return Container(
      height: heightT,
      width: widthT,
      child: Column(
        children: [
          MyCustomForm()
        ],
      ),
    );
  }
}